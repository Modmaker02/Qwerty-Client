package com.glassui;

import net.minecraft.client.gui.DrawContext;

public final class GlassRenderer {
    // ARGB colors - tweak these to taste
    public static final int GLASS         = 0x38FFFFFF; // normal fill
    public static final int GLASS_HOVER   = 0x66FFFFFF; // hovered fill
    public static final int GLASS_OFF     = 0x1CFFFFFF; // disabled fill
    public static final int GLASS_TOP     = 0x22FFFFFF; // top shine
    public static final int BORDER        = 0xFF8C8C8C; // grey outline
    public static final int BORDER_HOVER  = 0xFFC4C4C4;
    public static final int BORDER_OFF    = 0xFF5A5A5A;
    public static final int RADIUS        = 4;          // corner radius in px

    private GlassRenderer() {}

    /** Horizontal inset of the rounded corner for a row that is `row` px from the edge. */
    private static int inset(int row, int r) {
        if (r <= 0 || row >= r) return 0;
        double dy = r - row - 0.5;
        double dx = Math.sqrt(r * r - dy * dy);
        return (int) Math.ceil(r - dx);
    }

    public static void draw(DrawContext ctx, int x, int y, int w, int h,
                            boolean active, boolean hovered) {
        int r = Math.min(RADIUS, Math.min(w, h) / 2);
        int fill   = !active ? GLASS_OFF : hovered ? GLASS_HOVER : GLASS;
        int border = !active ? BORDER_OFF : hovered ? BORDER_HOVER : BORDER;

        for (int i = 0; i < h; i++) {
            int edge = Math.min(i, h - 1 - i);
            int ro = inset(edge, r);
            int ox1 = x + ro, ox2 = x + w - ro;
            int ry = y + i;

            if (i == 0 || i == h - 1) {
                ctx.fill(ox1, ry, ox2, ry + 1, border);
                continue;
            }
            int ri = inset(Math.max(0, edge - 1), Math.max(0, r - 1));
            int ix1 = Math.max(ox1 + 1, x + 1 + ri);
            int ix2 = Math.min(ox2 - 1, x + w - 1 - ri);

            ctx.fill(ox1, ry, ix1, ry + 1, border);          // left edge
            ctx.fill(ix2, ry, ox2, ry + 1, border);          // right edge
            ctx.fill(ix1, ry, ix2, ry + 1, fill);            // glass body
            if (active && i < h / 2) {
                ctx.fill(ix1, ry, ix2, ry + 1, GLASS_TOP);   // subtle top shine
            }
        }
    }
}
