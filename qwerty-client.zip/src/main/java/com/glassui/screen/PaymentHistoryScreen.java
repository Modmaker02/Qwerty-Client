package com.glassui.screen;

import com.glassui.RoundedDraw;
import com.glassui.payment.Money;
import com.glassui.payment.Payment;
import com.glassui.payment.PaymentStore;
import com.glassui.payment.Skins;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class PaymentHistoryScreen extends Screen {
    private static final int ACCENT = 0xFF3DDB7A;
    private static final int ROW = 22;
    private static final DateTimeFormatter FMT =
            DateTimeFormatter.ofPattern("MMM d, HH:mm:ss").withZone(ZoneId.systemDefault());

    private boolean leaderboard;
    private double scroll;
    private List<Payment> history = List.of();
    private List<PaymentStore.Total> tops = List.of();
    private int px, py, pw, ph, listTop, listBottom;

    public PaymentHistoryScreen() {
        super(Text.literal("PAYMENT HISTORY"));
    }

    @Override
    protected void init() {
        pw = Math.min(340, width - 16);
        ph = Math.min(176, height - 16);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        listTop = py + 44;
        listBottom = py + ph - 28;
        history = PaymentStore.latestFirst();
        tops = PaymentStore.totals();

        addDrawableChild(ButtonWidget.builder(Text.literal("History"), b -> {
            leaderboard = false;
            scroll = 0;
        }).dimensions(px + 10, py + 20, 70, 16).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Top payments"), b -> {
            leaderboard = true;
            scroll = 0;
        }).dimensions(px + 84, py + 20, 90, 16).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b -> close())
                .dimensions(px + pw - 62, py + ph - 22, 52, 16).build());
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private int count() {
        return leaderboard ? tops.size() : history.size();
    }

    private double maxScroll() {
        return Math.max(0, count() * ROW - (listBottom - listTop));
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scroll = Math.max(0, Math.min(maxScroll(), scroll - verticalAmount * ROW));
        return true;
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.renderBackground(ctx, mouseX, mouseY, delta);

        RoundedDraw.fill(ctx, px, py, pw, ph, 6, 0xEE0D1115);
        RoundedDraw.ring(ctx, px, py, pw, ph, 6, 0xFF000000 | (ACCENT & 0xFFFFFF));
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("PAYMENT HISTORY"), px + pw / 2, py + 7, ACCENT);

        int ux = leaderboard ? px + 84 : px + 10;
        int uw = leaderboard ? 90 : 70;
        ctx.fill(ux, py + 37, ux + uw, py + 39, ACCENT);

        ctx.fill(px + 8, listTop - 3, px + pw - 8, listTop - 2, 0x33FFFFFF);

        String foot = leaderboard ? tops.size() + " players" : history.size() + " payments";
        ctx.drawText(textRenderer, foot, px + 10, py + ph - 17, 0xFFA0A0A0, false);

        if (count() == 0) {
            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("No payments yet"), px + pw / 2, listTop + 24, 0xFFA0A0A0);
            return;
        }

        ctx.enableScissor(px + 8, listTop, px + pw - 8, listBottom);
        int n = count();
        for (int i = 0; i < n; i++) {
            int y = listTop + i * ROW - (int) scroll;
            if (y + ROW < listTop || y > listBottom) continue;
            if (i % 2 == 0) ctx.fill(px + 10, y, px + pw - 14, y + ROW - 2, 0x18FFFFFF);

            if (leaderboard) {
                PaymentStore.Total tot = tops.get(i);
                int rankCol = i == 0 ? 0xFFFFD23F : i == 1 ? 0xFFD0D0D0 : i == 2 ? 0xFFCD7F32 : 0xFF909090;
                ctx.drawText(textRenderer, "#" + (i + 1), px + 13, y + 6, rankCol, true);
                PlayerSkinDrawer.draw(ctx, Skins.get(tot.name()), px + 32, y + 2, 16);
                ctx.drawText(textRenderer, tot.name(), px + 54, y + 2, 0xFFFFFFFF, true);
                ctx.drawText(textRenderer, tot.count() + (tot.count() == 1 ? " payment" : " payments"),
                        px + 54, y + 12, 0xFFA0A0A0, false);
                drawAmount(ctx, Money.format(tot.total()), y);
            } else {
                Payment p = history.get(i);
                PlayerSkinDrawer.draw(ctx, Skins.get(p.name()), px + 13, y + 2, 16);
                ctx.drawText(textRenderer, p.name(), px + 35, y + 2, 0xFFFFFFFF, true);
                ctx.drawText(textRenderer, FMT.format(Instant.ofEpochMilli(p.time())) + "  -  " + ago(p.time()),
                        px + 35, y + 12, 0xFFA0A0A0, false);
                drawAmount(ctx, Money.format(p.amount()), y);
            }
        }
        ctx.disableScissor();

        double max = maxScroll();
        if (max > 0) {
            int track = listBottom - listTop;
            int thumb = Math.max(16, (int) (track * (track / (double) (track + max))));
            int ty = listTop + (int) ((track - thumb) * (scroll / max));
            ctx.fill(px + pw - 9, listTop, px + pw - 6, listBottom, 0x22FFFFFF);
            ctx.fill(px + pw - 9, ty, px + pw - 6, ty + thumb, 0xFF000000 | (ACCENT & 0xFFFFFF));
        }
    }

    private void drawAmount(DrawContext ctx, String text, int rowY) {
        int w = textRenderer.getWidth(text);
        ctx.drawText(textRenderer, text, px + pw - 18 - w, rowY + 7, 0xFF55FF88, true);
    }

    private static String ago(long t) {
        long s = Math.max(0, (System.currentTimeMillis() - t) / 1000);
        if (s < 60) return "just now";
        if (s < 3600) return (s / 60) + "m ago";
        if (s < 86400) return (s / 3600) + "h ago";
        return (s / 86400) + "d ago";
    }
}
