package com.glassui;

import com.glassui.alert.DonationAlerts;
import com.glassui.payment.PaymentStore;
import com.glassui.payment.PaymentTracker;
import com.glassui.screen.PaymentHistoryScreen;
import com.glassui.sneak.SneakLock;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

public class GlassUiClient implements ClientModInitializer {
    private static boolean pWasDown;

    @Override
    public void onInitializeClient() {
        PaymentStore.load();
        PaymentTracker.register();
        DonationAlerts.register();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            SneakLock.tick(client);
            historyKey(client);
        });
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> SneakLock.reset());
    }

    /** P opens / closes the Payment History screen (only when no other screen, e.g. chat, is open). */
    private static void historyKey(MinecraftClient client) {
        boolean down = GLFW.glfwGetKey(client.getWindow().getHandle(), GLFW.GLFW_KEY_P) == GLFW.GLFW_PRESS;
        if (down && !pWasDown) {
            if (client.currentScreen == null && client.player != null) {
                client.setScreen(new PaymentHistoryScreen());
            } else if (client.currentScreen instanceof PaymentHistoryScreen) {
                client.currentScreen.close();
            }
        }
        pWasDown = down;
    }
}
