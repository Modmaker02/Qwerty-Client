package com.glassui;

import net.minecraft.client.gui.DrawContext;

public final class RoundedDraw {
    private RoundedDraw() {}

    static int inset(int row, int r) {
        if (r <= 0 || row >= r) return 0;
        double dy = r - row - 0.5;
        double dx = Math.sqrt(r * r - dy * dy);
        return (int) Math.ceil(r - dx);
    }

    public static void fill(DrawContext c, int x, int y, int w, int h, int r, int color) {
        r = Math.min(r, Math.min(w, h) / 2);
        for (int i = 0; i < h; i++) {
            int in = inset(Math.min(i, h - 1 - i), r);
            c.fill(x + in, y + i, x + w - in, y + i + 1, color);
        }
    }

    /** 1px rounded outline. */
    public static void ring(DrawContext c, int x, int y, int w, int h, int r, int color) {
        r = Math.min(r, Math.min(w, h) / 2);
        for (int i = 0; i < h; i++) {
            int edge = Math.min(i, h - 1 - i);
            int ro = inset(edge, r);
            int ox1 = x + ro, ox2 = x + w - ro, ry = y + i;
            if (i == 0 || i == h - 1) {
                c.fill(ox1, ry, ox2, ry + 1, color);
                continue;
            }
            int ri = inset(Math.max(0, edge - 1), Math.max(0, r - 1));
            int ix1 = Math.max(ox1 + 1, x + 1 + ri);
            int ix2 = Math.min(ox2 - 1, x + w - 1 - ri);
            c.fill(ox1, ry, ix1, ry + 1, color);
            c.fill(ix2, ry, ox2, ry + 1, color);
        }
    }
}
