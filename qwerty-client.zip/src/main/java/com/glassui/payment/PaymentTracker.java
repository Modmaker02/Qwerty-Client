package com.glassui.payment;

import com.glassui.alert.DonationAlerts;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Only SERVER system messages are inspected (ClientReceiveMessageEvents.GAME) and the whole line must be exactly
 * "<name> paid you $<amount>". Player chat lines carry a name prefix / arrive as chat, so they never match.
 */
public final class PaymentTracker {
    private static final Pattern PAID = Pattern.compile(
            "^(\\.?[A-Za-z0-9_]{3,16}) paid you \\$([0-9][0-9,]*(?:\\.[0-9]+)?)\\s?([kKmMbBtT]?)[.!]?$");

    public static final long ALERT_MIN = 1_000_000L;

    private PaymentTracker() {}

    public static void register() {
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (overlay) return;
            handle(message.getString());
        });
    }

    static void handle(String raw) {
        if (raw == null) return;
        Matcher m = PAID.matcher(raw.trim());
        if (!m.matches()) return;

        String name = m.group(1);
        double base;
        try {
            base = Double.parseDouble(m.group(2).replace(",", ""));
        } catch (NumberFormatException e) {
            return;
        }
        double mult = switch (m.group(3).toLowerCase()) {
            case "k" -> 1e3;
            case "m" -> 1e6;
            case "b" -> 1e9;
            case "t" -> 1e12;
            default -> 1;
        };
        long amount = Math.round(base * mult);
        if (amount <= 0) return;

        Skins.remember(name);
        PaymentStore.add(new Payment(name, amount, System.currentTimeMillis()));
        if (amount >= ALERT_MIN) DonationAlerts.enqueue(name, amount);
    }
}
