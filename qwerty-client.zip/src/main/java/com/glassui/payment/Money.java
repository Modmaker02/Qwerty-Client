package com.glassui.payment;

import java.util.Locale;

public final class Money {
    private Money() {}

    public static String format(double v) {
        double a = Math.abs(v);
        if (a >= 1e12) return "$" + trim(v / 1e12) + "T";
        if (a >= 1e9) return "$" + trim(v / 1e9) + "B";
        if (a >= 1e6) return "$" + trim(v / 1e6) + "M";
        if (a >= 1e3) return "$" + trim(v / 1e3) + "K";
        return "$" + (long) Math.floor(v);
    }

    private static String trim(double d) {
        String s = String.format(Locale.ROOT, "%.2f", Math.floor(d * 100.0) / 100.0);
        if (s.indexOf('.') >= 0) {
            s = s.replaceAll("0+$", "");
            s = s.replaceAll("\\.$", "");
        }
        return s;
    }
}
