package com.glassui.payment;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.util.DefaultSkinHelper;
import net.minecraft.entity.player.SkinTextures;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public final class Skins {
    private static final Map<String, SkinTextures> CACHE = new HashMap<>();

    private Skins() {}

    /** Call when a payment arrives so the payer's real skin is cached while they are still online. */
    public static void remember(String name) {
        lookup(name);
    }

    public static SkinTextures get(String name) {
        SkinTextures t = lookup(name);
        if (t != null) return t;
        UUID id = UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8));
        return DefaultSkinHelper.getSkinTextures(id);
    }

    private static SkinTextures lookup(String name) {
        String key = name.toLowerCase(Locale.ROOT);
        ClientPlayNetworkHandler handler = MinecraftClient.getInstance().getNetworkHandler();
        if (handler != null) {
            PlayerListEntry e = handler.getPlayerListEntry(name);
            if (e != null) CACHE.put(key, e.getSkinTextures());
        }
        return CACHE.get(key);
    }
}
