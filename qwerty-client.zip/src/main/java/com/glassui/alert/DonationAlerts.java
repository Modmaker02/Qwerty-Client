package com.glassui.alert;

import com.glassui.RoundedDraw;
import com.glassui.payment.Money;
import com.glassui.payment.Skins;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public final class DonationAlerts {
    private static final int W = 250, H = 60;
    private static final double DROP = 0.6, EXIT = 0.5;
    private static final Random R = new Random();
    private static final int[] GOLD = {0xFFD700, 0xFFC107, 0xFFE066, 0xFFB300};
    private static final int[] PAL = {0xFF4D4D, 0x4DFF88, 0x4DA6FF, 0xFFD24D, 0xFF4DD2, 0xFFFFFF, 0xB84DFF};

    private static final ArrayDeque<Alert> QUEUE = new ArrayDeque<>();
    private static final List<Particle> PARTS = new ArrayList<>();
    private static final List<Rocket> ROCKETS = new ArrayList<>();
    private static Alert cur;
    private static long lastNs;
    private static double flashWhite, flashGold;

    private DonationAlerts() {}

    private static final class Alert {
        final String name;
        final long amount;
        final int tier;
        long startNs;
        final double countDur, hold, total;
        final double[] launches;
        int launchIdx;
        double sparkleAcc, rainAcc, nextTick;
        boolean endDone;

        Alert(String n, long a) {
            name = n;
            amount = a;
            tier = a >= 100_000_000L ? 3 : a >= 50_000_000L ? 2 : 1;
            countDur = tier == 3 ? 3.0 : tier == 2 ? 2.2 : 1.6;
            hold = tier == 3 ? 6.0 : tier == 2 ? 4.5 : 3.0;
            total = DROP + countDur + hold + EXIT;
            launches = tier == 3
                    ? new double[]{0.5, 0.9, 1.3, 1.7, 2.1, 2.6, 3.1, 3.7, 4.3, 5.0, 5.8}
                    : tier == 2 ? new double[]{0.8, 1.5, 2.2, 3.0} : new double[]{1.0};
        }

        double scale() {
            return tier == 3 ? 1.4 : tier == 2 ? 1.2 : 1.0;
        }
    }

    private static final class Particle {
        double x, y, vx, vy, g, life, max;
        int size, rgb;
    }

    private static final class Rocket {
        double x, y, ty, vy;
        int tier;
    }

    public static void enqueue(String name, long amount) {
        if (QUEUE.size() < 20) QUEUE.add(new Alert(name, amount));
    }

    public static void register() {
        HudRenderCallback.EVENT.register(DonationAlerts::render);
    }

    // ---------------------------------------------------------------- render loop

    private static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        if (cur == null && QUEUE.isEmpty() && PARTS.isEmpty() && ROCKETS.isEmpty() && flashWhite <= 0 && flashGold <= 0) {
            lastNs = 0;
            return;
        }
        long now = System.nanoTime();
        double dt = lastNs == 0 ? 0 : Math.min(0.1, (now - lastNs) / 1e9);
        lastNs = now;
        int sw = ctx.getScaledWindowWidth();
        int sh = ctx.getScaledWindowHeight();

        if (cur == null && !QUEUE.isEmpty()) {
            cur = QUEUE.poll();
            cur.startNs = now;
            startSounds(cur);
        }
        double t = 0;
        if (cur != null) {
            t = (now - cur.startNs) / 1e9;
            step(cur, t, dt, sw, sh);
        }
        stepParticles(dt, sh);
        drawParticles(ctx);
        if (cur != null) {
            drawCard(ctx, cur, t, sw, now);
            if (t >= cur.total) cur = null;
        }
        drawFlash(ctx, sw, sh);
    }

    private static double cardY(Alert a, double t) {
        double hs = H * a.scale();
        double exitStart = a.total - EXIT;
        if (t < DROP) return lerp(-hs - 12, 14, easeOutBack(t / DROP));
        if (t > exitStart) {
            double p = Math.min(1, (t - exitStart) / EXIT);
            return lerp(14, -hs - 12, p * p * p);
        }
        return 14;
    }

    private static void step(Alert a, double t, double dt, int sw, int sh) {
        double s = a.scale();
        boolean visible = t < a.total - EXIT;

        if (visible && t > 0.2) {
            a.sparkleAcc += dt * 28;
            double y = cardY(a, t);
            while (a.sparkleAcc >= 1) {
                a.sparkleAcc -= 1;
                Particle p = new Particle();
                p.x = sw / 2.0 + (R.nextDouble() - 0.5) * W * s;
                p.y = y + R.nextDouble() * H * s;
                p.vx = (R.nextDouble() - 0.5) * 20;
                p.vy = -10 - R.nextDouble() * 25;
                p.life = p.max = 0.6 + R.nextDouble() * 0.5;
                p.size = R.nextInt(3) == 0 ? 2 : 1;
                p.rgb = a.tier == 1 ? (R.nextBoolean() ? 0xFFFFFF : 0x7DFFD6) : (R.nextBoolean() ? 0xFFFFFF : 0xFFE066);
                PARTS.add(p);
            }
        }

        if (a.tier >= 2 && t > 0.2 && t < a.total - EXIT - 0.5) {
            a.rainAcc += dt * (a.tier == 2 ? 45 : 100);
            while (a.rainAcc >= 1) {
                a.rainAcc -= 1;
                Particle p = new Particle();
                p.x = R.nextDouble() * sw;
                p.y = -4;
                p.vx = (R.nextDouble() - 0.5) * 20;
                p.vy = 70 + R.nextDouble() * 90;
                p.g = 40;
                p.life = p.max = 6.0;
                p.size = 2 + (R.nextInt(4) == 0 ? 1 : 0) + (a.tier == 3 ? 1 : 0);
                p.rgb = R.nextInt(8) == 0 ? 0x4DEEEA : GOLD[R.nextInt(GOLD.length)];
                PARTS.add(p);
            }
        }

        while (a.launchIdx < a.launches.length && t >= a.launches[a.launchIdx]) {
            a.launchIdx++;
            Rocket r = new Rocket();
            r.x = sw * (0.12 + 0.76 * R.nextDouble());
            r.y = sh + 4;
            r.ty = sh * (0.12 + 0.30 * R.nextDouble());
            r.vy = -sh * 1.0;
            r.tier = a.tier;
            ROCKETS.add(r);
            play(SoundEvents.ENTITY_FIREWORK_ROCKET_LAUNCH, 1.0f, 0.35f);
        }

        double countEnd = DROP + a.countDur;
        if (t > DROP && t < countEnd && t >= a.nextTick) {
            double frac = (t - DROP) / a.countDur;
            play(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, (float) (0.7 + frac * 1.3), 0.22f);
            a.nextTick = t + 0.075;
        }

        if (!a.endDone && t >= countEnd) {
            a.endDone = true;
            endSounds(a);
            if (a.tier >= 2) flashGold = a.tier == 3 ? 0.35 : 0.22;
            burst(sw / 2.0, cardY(a, t) + H * s / 2.0, a.tier);
        }
    }

    private static void stepParticles(double dt, int sh) {
        flashWhite = Math.max(0, flashWhite - dt * 1.2);
        flashGold = Math.max(0, flashGold - dt * 1.0);

        Iterator<Particle> it = PARTS.iterator();
        while (it.hasNext()) {
            Particle p = it.next();
            p.vy += p.g * dt;
            p.x += p.vx * dt;
            p.y += p.vy * dt;
            p.life -= dt;
            if (p.life <= 0 || p.y > sh + 10) it.remove();
        }

        List<Rocket> done = new ArrayList<>();
        for (Rocket r : ROCKETS) {
            r.y += r.vy * dt;
            Particle tr = new Particle();
            tr.x = r.x;
            tr.y = r.y;
            tr.vx = (R.nextDouble() - 0.5) * 14;
            tr.vy = 20 + R.nextDouble() * 20;
            tr.life = tr.max = 0.35;
            tr.size = 1;
            tr.rgb = R.nextBoolean() ? 0xFFB347 : 0xFFFFFF;
            PARTS.add(tr);
            if (r.y <= r.ty) {
                burst(r.x, r.y, r.tier);
                done.add(r);
            }
        }
        ROCKETS.removeAll(done);
    }

    private static void burst(double x, double y, int tier) {
        int count = tier == 3 ? 80 : tier == 2 ? 55 : 36;
        int c1 = PAL[R.nextInt(PAL.length)];
        int c2 = PAL[R.nextInt(PAL.length)];
        double max = 80 + tier * 25;
        for (int i = 0; i < count; i++) {
            double ang = R.nextDouble() * Math.PI * 2;
            double sp = (0.3 + 0.7 * Math.sqrt(R.nextDouble())) * max;
            Particle p = new Particle();
            p.x = x;
            p.y = y;
            p.vx = Math.cos(ang) * sp;
            p.vy = Math.sin(ang) * sp;
            p.g = 110;
            p.life = p.max = 0.9 + R.nextDouble() * 0.7;
            p.size = tier >= 2 && R.nextInt(3) == 0 ? 3 : 2;
            p.rgb = R.nextDouble() < 0.65 ? c1 : c2;
            PARTS.add(p);
        }
        play(SoundEvents.ENTITY_FIREWORK_ROCKET_BLAST, (float) (0.9 + R.nextDouble() * 0.3), 0.55f);
        if (tier >= 2) play(SoundEvents.ENTITY_FIREWORK_ROCKET_TWINKLE, 1.0f, 0.4f);
    }

    // ---------------------------------------------------------------- drawing

    private static void drawParticles(DrawContext ctx) {
        for (Particle p : PARTS) {
            double k = p.life / p.max;
            double al = k > 0.5 ? 1.0 : k * 2.0;
            int a = Math.max(0, Math.min(255, (int) (al * 255)));
            int col = (a << 24) | (p.rgb & 0xFFFFFF);
            int x = (int) p.x, y = (int) p.y;
            ctx.fill(x, y, x + p.size, y + p.size, col);
        }
        for (Rocket r : ROCKETS) {
            int x = (int) r.x, y = (int) r.y;
            ctx.fill(x, y, x + 2, y + 3, 0xFFFFFFFF);
        }
    }

    private static void drawFlash(DrawContext ctx, int sw, int sh) {
        if (flashWhite > 0) {
            int a = Math.min(255, (int) (flashWhite * 255));
            ctx.fill(0, 0, sw, sh, (a << 24) | 0xFFFFFF);
        }
        if (flashGold > 0) {
            int a = Math.min(255, (int) (flashGold * 255));
            ctx.fill(0, 0, sw, sh, (a << 24) | 0xFFD24D);
        }
    }

    private static void drawCard(DrawContext ctx, Alert a, double t, int sw, long nowNs) {
        double s = a.scale();
        double y = cardY(a, t);
        double x0 = sw / 2.0 - W * s / 2.0;
        double wall = nowNs / 1e9;

        int accent;
        int titleCol;
        int amountCol;
        String title;
        if (a.tier == 1) {
            accent = 0x3DDBB0;
            titleCol = 0x3DDBB0;
            amountCol = 0x55FFAA;
            title = "Donation";
        } else if (a.tier == 2) {
            accent = 0xFFC83D;
            titleCol = 0xFFD23F;
            amountCol = 0xFFD23F;
            title = "Big Donation";
        } else {
            accent = hsv((wall * 0.45) % 1.0);
            titleCol = hsv((wall * 0.45 + 0.15) % 1.0);
            double mix = 0.5 + 0.5 * Math.sin(wall * 8);
            amountCol = mixColor(0xFFD23F, 0xFFFFFF, mix);
            title = "MEGA DONATION";
        }

        double frac = Math.max(0, Math.min(1, (t - DROP) / a.countDur));
        double eased = 1 - Math.pow(1 - frac, 3);
        String amountText = frac >= 1 ? Money.format(a.amount) : Money.format(a.amount * eased);
        double since = t - (DROP + a.countDur);
        float pop = since >= 0 && since < 1 ? (float) (1 + 0.2 * Math.exp(-since * 9)) : 1f;

        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        var m = ctx.getMatrices();
        m.pushMatrix();
        m.translate((float) x0, (float) y);
        m.scale((float) s, (float) s);

        RoundedDraw.fill(ctx, 0, 0, W, H, 6, 0xF00D1115);
        if (a.tier >= 2) {
            double pulse = 0.5 + 0.5 * Math.sin(t * 6);
            int ga = (int) (60 + 120 * pulse);
            RoundedDraw.ring(ctx, -2, -2, W + 4, H + 4, 8, (ga << 24) | accent);
        }
        RoundedDraw.ring(ctx, 0, 0, W, H, 6, 0xFF000000 | accent);

        RoundedDraw.fill(ctx, 8, 8, 44, 44, 4, 0x55000000 | accent);
        PlayerSkinDrawer.draw(ctx, Skins.get(a.name), 10, 10, 40);

        ctx.drawText(tr, title, 60, 8, 0xFF000000 | titleCol, true);
        ctx.drawText(tr, a.name + " donated " + Money.format(a.amount) + "!", 60, 20, 0xFFFFFFFF, true);

        m.pushMatrix();
        m.translate(60f, 32f);
        m.scale(2f * pop, 2f * pop);
        ctx.drawText(tr, amountText, 0, 0, 0xFF000000 | amountCol, true);
        m.popMatrix();

        m.popMatrix();
    }

    // ---------------------------------------------------------------- sounds

    private static void startSounds(Alert a) {
        play(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 0.6f);
        if (a.tier >= 2) play(SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, a.tier == 3 ? 0.85f : 1.0f, 0.8f);
        if (a.tier == 3) {
            play(SoundEvents.ENTITY_FIREWORK_ROCKET_LARGE_BLAST, 1.0f, 0.9f);
            flashWhite = 0.35;
        }
    }

    private static void endSounds(Alert a) {
        play(SoundEvents.ENTITY_PLAYER_LEVELUP, a.tier == 1 ? 1.2f : 1.0f, 0.8f);
        if (a.tier >= 2) play(SoundEvents.ENTITY_FIREWORK_ROCKET_LARGE_BLAST, 1.0f, 0.8f);
        if (a.tier == 3) play(SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, 1.1f, 0.9f);
    }

    private static void play(SoundEvent e, float pitch, float volume) {
        MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(e, pitch, volume));
    }

    // ---------------------------------------------------------------- math helpers

    private static double lerp(double a, double b, double p) {
        return a + (b - a) * p;
    }

    private static double easeOutBack(double p) {
        p = Math.max(0, Math.min(1, p));
        double c1 = 1.70158, c3 = c1 + 1;
        return 1 + c3 * Math.pow(p - 1, 3) + c1 * Math.pow(p - 1, 2);
    }

    private static int mixColor(int a, int b, double k) {
        int r = (int) lerp((a >> 16) & 0xFF, (b >> 16) & 0xFF, k);
        int g = (int) lerp((a >> 8) & 0xFF, (b >> 8) & 0xFF, k);
        int bl = (int) lerp(a & 0xFF, b & 0xFF, k);
        return (r << 16) | (g << 8) | bl;
    }

    private static int hsv(double h) {
        double f = h * 6 - Math.floor(h * 6);
        double q = 1 - f;
        double r, g, b;
        switch ((int) (h * 6) % 6) {
            case 0 -> { r = 1; g = f; b = 0; }
            case 1 -> { r = q; g = 1; b = 0; }
            case 2 -> { r = 0; g = 1; b = f; }
            case 3 -> { r = 0; g = q; b = 1; }
            case 4 -> { r = f; g = 0; b = 1; }
            default -> { r = 1; g = 0; b = q; }
        }
        return ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }
}
